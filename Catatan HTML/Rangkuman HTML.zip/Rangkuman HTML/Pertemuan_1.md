# PENGANTAR_WEB

**Pengantar web adalah bagian dari suatu halaman web yang memberikan informasi awal atau konteks singkat mengenai isi halaman tersebut. 

## DAFTAR MATERI
1. DEFINISI WEB
Web adalah singkatan dari "World Wide Web," sebuah sistem informasi global yang terhubung melalui internet.
2. PENGERTIAN WEB
Web adalah sistem informasi global di internet yang memungkinkan akses dan pertukaran berbagai sumber daya, seperti halaman web, gambar, dan dokumen.
3. TUJUAN WEB
Tujuan web adalah menyediakan akses cepat dan efisien ke berbagai informasi,
## TEMAN KELOMPOK 
- Fadil
- Ardi
- Fachri
- Rehan 
## CEKLIS

- [x] BAIK
+ [x] terbaik 

> [!faq]



# HTML
HTML adalah bahasa markup yang digunakan untuk membuat dan merancang halaman web.  
`<html>`

# CSS
```CSS
Body{
Background-color:White;

}

```


![gambar](Aset/Foto.png)
