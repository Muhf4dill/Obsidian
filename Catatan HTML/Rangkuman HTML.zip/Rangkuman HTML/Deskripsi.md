![gambar](Aset/HCJ.jpg)
# HTML

Gambar pertama mengibaratkan HTML di mana cuma  berbentuk pondasi sama dengan HTML cuma berbentuk struktur belum ada warna atau memberikan interaksi.

# CSS
Gambar kedua mengibaratkan CSS. Dimana CSS berfungsi menghiasi website. Sama seperti gambar kedua yang sudah di hiasi seperti ada warna, pintu, jendela, dan cerobong asap.

# JAVASCRIPT 
Gambar ketiga mengibaratkan Javascript. Dimana Javascript berfungsi memberikan interaksi sama dengan Gambar ketiga yang di berikan interaksi seperti keluar asap, lampu nyala atau saklar on, pintu tertutup .
